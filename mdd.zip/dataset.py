import os
from typing import Dict

import librosa
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset

from utils import (
    ERROR_PAD_ID,
    PAD_TOKEN_ID,
    SAMPLE_RATE,
    canonical_time_to_tensor,
    parse_error,
    text_to_tensor,
)


class MDDDataset(Dataset):
    def __init__(self, data: pd.DataFrame, wav_dir: str, vocab: Dict[str, int]):
        self.data = data
        self.len_data = len(data)
        self.path = list(data['Path']) if 'Path' in data.columns else [None] * self.len_data
        self.audio_path = (
            list(data['AudioPath'])
            if 'AudioPath' in data.columns
            else list(data['audio_path']) if 'audio_path' in data.columns else [None] * self.len_data
        )
        self.canonical = list(data['Canonical'])
        self.transcript = list(data['Transcript'])
        self.error = list(data['Error'])
        self.canonical_time = list(data['Canonical_time'])
        self.wav_dir = wav_dir
        self.vocab = vocab

    def __getitem__(self, index):
        wav_path = self._resolve_wav_path(index)
        waveform, _ = librosa.load(wav_path, sr=SAMPLE_RATE)
        linguistic = text_to_tensor(self.canonical[index], self.vocab)
        transcript = text_to_tensor(self.transcript[index], self.vocab)
        error = self.error[index]
        canonical_time = self.canonical_time[index]
        return waveform, linguistic, transcript, error, canonical_time

    def __len__(self):
        return self.len_data

    def _resolve_wav_path(self, index: int) -> str:
        if self.audio_path[index]:
            audio_path = str(self.audio_path[index])
            return audio_path

        raw_path = str(self.path[index])
        if raw_path.lower().endswith('.wav'):
            return os.path.join(self.wav_dir, raw_path)
        return os.path.join(self.wav_dir, f"{raw_path}.wav")


def make_collate_fn(mode: str, feature_extractor, device: torch.device, vocab: Dict[str, int]):
    if mode not in {'wl', 'mfa'}:
        raise ValueError("mode must be either 'wl' or 'mfa'")

    def collate_fn(batch):
        with torch.no_grad():
            max_col = [-1] * 4

            for row in batch:
                error = parse_error(row[3])
                max_col[0] = max(max_col[0], row[0].shape[0])
                max_col[1] = max(max_col[1], len(row[1]))
                max_col[2] = max(max_col[2], len(row[2]))
                max_col[3] = max(max_col[3], len(error))

            cols = {
                'waveform': [],
                'linguistic': [],
                'transcript': [],
                'error': [],
                'outputlengths': [],
            }

            if mode == 'mfa':
                cols['canonical_time'] = []
                max_length = max_col[0] // 320

            for row in batch:
                if mode == 'mfa':
                    canonical_time = canonical_time_to_tensor(row[4], max_length=max_length, vocab=vocab)
                    cols['canonical_time'].append(canonical_time)

                pad_wav = np.concatenate([row[0], np.zeros(max_col[0] - row[0].shape[0])])
                cols['waveform'].append(pad_wav)

                row[1].extend([PAD_TOKEN_ID] * (max_col[1] - len(row[1])))
                cols['linguistic'].append(row[1])

                cols['outputlengths'].append(len(row[2]))
                row[2].extend([PAD_TOKEN_ID] * (max_col[2] - len(row[2])))
                cols['transcript'].append(row[2])

                error = parse_error(row[3])
                error.extend([ERROR_PAD_ID] * (max_col[3] - len(error)))
                cols['error'].append(error)

            inputs = feature_extractor(cols['waveform'], sampling_rate=SAMPLE_RATE)
            input_values = torch.tensor(inputs.input_values, device=device)
            cols['linguistic'] = torch.tensor(cols['linguistic'], dtype=torch.long, device=device)
            cols['transcript'] = torch.tensor(cols['transcript'], dtype=torch.long, device=device)
            cols['error'] = torch.tensor(cols['error'], dtype=torch.long, device=device)
            cols['outputlengths'] = torch.tensor(cols['outputlengths'], dtype=torch.long, device=device)

            if mode == 'mfa':
                cols['canonical_time'] = torch.stack(cols['canonical_time']).to(device)
                return (
                    input_values,
                    cols['linguistic'],
                    cols['transcript'],
                    cols['error'],
                    cols['outputlengths'],
                    cols['canonical_time'],
                )

            return (
                input_values,
                cols['linguistic'],
                cols['transcript'],
                cols['error'],
                cols['outputlengths'],
            )

    return collate_fn
