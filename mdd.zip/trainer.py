import os

import librosa
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from jiwer import wer
from torch.utils.data import DataLoader
from tqdm import tqdm

from dataset import MDDDataset, make_collate_fn
from model import MFAWav2Vec2Linguistic, Wav2Vec2Linguistic
from utils import (
    BLANK_TOKEN_ID,
    SAMPLE_RATE,
    build_feature_extractor,
    canonical_time_to_tensor,
    create_decoder,
    get_device,
    load_vocab,
    text_to_tensor,
)


class MDDTrainer:
    def __init__(self, args):
        self.args = args
        self.device = get_device()
        self.feature_extractor = build_feature_extractor()
        self.vocab = load_vocab(args.vocab_path)

        self.df_train = pd.read_csv(args.train_csv)
        self.df_dev = pd.read_csv(args.dev_csv)

        self.train_dataset = MDDDataset(self.df_train, wav_dir=args.wav_dir, vocab=self.vocab)
        self.train_loader = DataLoader(
            dataset=self.train_dataset,
            batch_size=args.batch_size,
            shuffle=True,
            collate_fn=make_collate_fn(args.mode, self.feature_extractor, self.device, self.vocab),
        )

        model_cls = Wav2Vec2Linguistic if args.mode == 'wl' else MFAWav2Vec2Linguistic
        self.model = model_cls.from_pretrained(args.pretrained_model)
        self.model.freeze_feature_extractor()
        self.model = self.model.to(self.device)

        self.decoder_ctc = create_decoder()
        self.optimizer = torch.optim.AdamW(self.model.parameters(), lr=args.learning_rate)
        self.ctc_loss = nn.CTCLoss(blank=BLANK_TOKEN_ID)
        self.min_wer = 100.0

        os.makedirs(args.checkpoint_dir, exist_ok=True)

    def train(self):
        for epoch in range(self.args.num_epoch):
            running_loss = self._train_one_epoch(epoch)
            print(f"Training loss: {sum(running_loss) / len(running_loss)}")

            if epoch >= self.args.eval_start_epoch:
                epoch_wer = self._evaluate()
                if epoch_wer < self.min_wer:
                    print('save_checkpoint...')
                    self.min_wer = epoch_wer
                    ckpt_name = f"checkpoint_{self.args.mode}.pth"
                    ckpt_path = os.path.join(self.args.checkpoint_dir, ckpt_name)
                    torch.save(self.model.state_dict(), ckpt_path)

                print(f"wer checkpoint {epoch}: {epoch_wer}")
                print(f"min_wer: {self.min_wer}")

    def _train_one_epoch(self, epoch):
        self.model.train().to(self.device)
        running_loss = []
        print(f"EPOCH {epoch}:")

        for _, data in tqdm(enumerate(self.train_loader), total=len(self.train_loader)):
            if self.args.mode == 'wl':
                acoustic, linguistic, labels, _, target_lengths = data
            else:
                acoustic, _, labels, _, target_lengths, linguistic = data

            logits = self.model(acoustic, linguistic)
            logits = logits.transpose(0, 1)
            input_lengths = torch.full(
                size=(logits.shape[1],),
                fill_value=logits.shape[0],
                dtype=torch.long,
                device=self.device,
            )
            logits = F.log_softmax(logits, dim=2)
            loss = self.ctc_loss(logits, labels, input_lengths, target_lengths)

            running_loss.append(loss.item())
            loss.backward()
            self.optimizer.step()
            self.optimizer.zero_grad()

        return running_loss

    def _evaluate(self):
        self.model.eval().to(self.device)
        worderrorrate = []

        with torch.no_grad():
            for point in tqdm(range(len(self.df_dev))):
                wav_path = os.path.join(self.args.wav_dir, f"{self.df_dev['Path'][point]}.wav")
                acoustic, _ = librosa.load(wav_path, sr=SAMPLE_RATE)
                acoustic = self.feature_extractor(acoustic, sampling_rate=SAMPLE_RATE)
                acoustic = torch.tensor(acoustic.input_values, device=self.device)

                transcript = self.df_dev['Transcript'][point]

                if self.args.mode == 'wl':
                    canonical = text_to_tensor(self.df_dev['Canonical'][point], self.vocab)
                    canonical = torch.tensor(canonical, dtype=torch.long, device=self.device)
                    model_input = canonical.unsqueeze(0)
                else:
                    canonical = canonical_time_to_tensor(
                        self.df_dev['Canonical_time'][point],
                        max_length=acoustic.shape[1] // 320,
                        vocab=self.vocab,
                    ).to(self.device)
                    model_input = canonical.unsqueeze(0)

                logits = self.model(acoustic, model_input)
                logits = F.log_softmax(logits.squeeze(0), dim=1)
                hypothesis = self.decoder_ctc.decode(logits.detach().cpu().numpy()).strip()
                worderrorrate.append(wer(transcript, hypothesis))

        return sum(worderrorrate) / len(worderrorrate)
